using Microsoft.EntityFrameworkCore;
using TodoApi.Controllers;
using TodoApi.Data;
using TodoApi.Models;
using Xunit;
using Microsoft.AspNetCore.Mvc;

namespace TodoApi.Tests
{
    public class TodoControllerTests
    {
        
        private TodoContext GetInMemoryDatabase()                                                   // aqui cria um bamco a cada teste
        {
            var options = new DbContextOptionsBuilder<TodoContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;

            return new TodoContext(options);
        }

        [Fact]
        public async Task GetAll_ReturnsAllItems()                                         // teste get all
        {
            
            var db = GetInMemoryDatabase();
            db.Todos.Add(new TodoItem { Name = "Task 1", IsDone = false });
            db.Todos.Add(new TodoItem { Name = "Task 2", IsDone = true });
            await db.SaveChangesAsync();

            var controller = new TodoController(db);

            
            var result = await controller.GetAll();
            var okResult = result.Result as OkObjectResult;
            var items = okResult.Value as IEnumerable<TodoItem>;

          
            Assert.Equal(2, items.Count());
        }

        
        [Fact]
        public async Task Create_AddsNewItem()                                                            // teste do ppost
        {
            
            var db = GetInMemoryDatabase();
            var controller = new TodoController(db);
            var newItem = new TodoItem { Name = "New Task", IsDone = false };

            
            var result = await controller.Create(newItem);
            var created = result.Result as CreatedAtActionResult;
            var item = created.Value as TodoItem;

           
            Assert.NotNull(item);
            Assert.Equal("New Task", item.Name);
            Assert.Equal(1, db.Todos.Count());
        }

        [Fact]
        public async Task Get_ReturnsItem_WhenItExists()                                            // get por id que retorna o item
        {
            var db = GetInMemoryDatabase();
            db.Todos.Add(new TodoItem { Id = 1, Name = "Test", IsDone = false });
            await db.SaveChangesAsync();

            var controller = new TodoController(db);

            var result = await controller.Get(1);
            var ok = result.Result as OkObjectResult;
            var item = ok.Value as TodoItem;

            Assert.NotNull(item);
            Assert.Equal("Test", item.Name);
        }

        [Fact]
        public async Task Get_ReturnsNotFound_WhenItemMissing()                                         //teste do Get do ID
        {
            var db = GetInMemoryDatabase();
            var controller = new TodoController(db);

            var result = await controller.Get(99);

            Assert.IsType<NotFoundResult>(result.Result);
        }

        [Fact]
        public async Task Delete_RemovesItem()                                            //teste do delete
        {
            var db = GetInMemoryDatabase();
            db.Todos.Add(new TodoItem { Id = 1, Name = "Del Task" });
            await db.SaveChangesAsync();

            var controller = new TodoController(db);

            var result = await controller.Delete(1);

            Assert.IsType<NoContentResult>(result); 
        }

        [Fact]
        public async Task Update_ModifiesItem()                                                          // teste do put
        {
            var db = GetInMemoryDatabase();
            db.Todos.Add(new TodoItem { Id = 1, Name = "Old Name", IsDone = false });
            await db.SaveChangesAsync();

db.ChangeTracker.Clear();

            var controller = new TodoController(db);
            var updatedItem = new TodoItem { Id = 1, Name = "Updated Name", IsDone = true };

            var result = await controller.Update(1, updatedItem);

            Assert.IsType<NoContentResult>(result);

            var saved = db.Todos.First();
            Assert.Equal("Updated Name", saved.Name);
            Assert.True(saved.IsDone);
        }
    }
}
